const express=require("express");
const app=express();
app.get("/" ,(req,res)=>{
    res.send("hello express user welcome all of you in express");
});
app.get("/about",(req,res)=>{
    res.send("hello about page how are you tell me")
})
app.listen(8000,()=>{
    console.log("the app is listing on 8000");
})